---
AIGC:
    Label: "1"
    ContentProducer: 001191110102MACQD9K64018705
    ProduceID: 2900969869286793_0/project_7657151939519676710-files/FamilyStar/DESIGN_HANDOFF.md
    ReservedCode1: ""
    ContentPropagator: 001191110102MACQD9K64028705
    PropagateID: 2900969869286793#1785339863760
    ReservedCode2: ""
---
# FamilyStar 全端设计交接文档

> 给前端开发（猴子）：孩子端 6 页 + 家长端 9 页高保真页面全部完成，纯手写 HTML/CSS/JS，无框架、无构建，可直接浏览器打开。
> 本文档说明文件结构、设计规范与产品逻辑的对应关系、以及落地到 React 技术栈的建议。
> 更新：2026-07-29（家长端 9 页完成；导航为底部固定导航栏；家长端入口为 dashboard.html，多页面真实跳转）

---

## 1. 文件清单

```
design/
├── DESIGN_HANDOFF.md      ← 本文档
├── PRD_Latest.html        ← 产品需求文档（人类可读版，v0.6.4）
├── ── 孩子端 ──
├── child-app.html         ← 孩子端 App 单文件演示版（5页内部跳转）⬅ 演示入口
├── child-home.html        ← 首页
├── child-checkin.html     ← 打卡任务页
├── child-achievements.html← 成就页
├── child-rewards.html     ← 奖励页
├── child-profile.html     ← 我的页
├── child-records.html     ← 记录页
├── ── 家长端 ──
├── parent-app.html        ← 家长端单文件演示版（9页内部跳转）⬅ 在线演示入口
├── dashboard.html         ← 家长端总览 Dashboard（开发基准首页）
├── parent-tasks.html      ← 任务管理（列表+筛选+批量+类型管理+创建任务弹窗）
├── parent-review.html     ← 打卡审核（待审核/历史记录）
├── parent-rewards.html    ← 奖励管理（兑换审批/奖励池/许愿墙）
├── parent-levels.html     ← 等级与成就（阶梯配置/加成表/等级奖励/发放设置/徽章墙）
├── parent-stats.html      ← 数据面板（孩子维度/任务维度/时间维度）
├── parent-records.html    ← 成长记录（相册时间线/习惯追踪/学习笔记）
├── parent-family.html     ← 家庭成员（孩子档案/家长管理/邀请/家庭设置）
└── parent-settings.html   ← 设置（打卡规则/Streak倍率/通知/数据/危险区）
```

**演示方式**：孩子端打开 `child-app.html`（底部 5 Tab 切换）；家长端打开 `parent-app.html`（底部 9 Tab 切换）。⚠️ 独立页面之间的相对链接需整个文件夹一起用（解压 zip 后本地打开 dashboard.html 即可 9 页互跳）；在扣子/网页端单文件预览时请用 SPA 演示版（child-app.html / parent-app.html）。

---

## 2. 技术栈对齐

| 层 | 项目目标栈 | 本设计稿用的等价方案 | 迁移说明 |
|---|---|---|---|
| 框架 | React 18 + TypeScript | 原生 JS 函数 | 页面结构 = 组件树，JS 交互函数已按职责命名，可直接翻译成 hooks |
| 样式 | Tailwind CSS（视觉风格参考 [animal-island-ui](https://github.com/guokaigdg/animal-island-ui) 动森风格但独立实现 Tokens，规避 CC BY-NC 4.0 商业限制） | 手写 CSS 变量 + 工具类 | :root 变量与 Tailwind theme 一一对应（见 §3） |
| 动画 | Framer Motion | CSS @keyframes + transition | 动画名/时长/缓动都已定义，直接映射 motion variants |
| 图标 | Lucide | Emoji 占位 | 每个 emoji 处建议的 Lucide 图标见 §5 |
| 字体 | — | Google Fonts: Fredoka One + Nunito | index.html 直接引 link 即可 |
| 架构 | 微内核插件化（ModuleRegistry + EventBus + manifest）— PRD §6.3 | — | 功能模块独立开发、热插拔；打卡/积分/等级/奖励/成长记录各自为插件，通过 EventBus 解耦通信；家长后台可一键开关各模块 |

---

## 3. 设计 Tokens（→ tailwind.config）

### 3.1 颜色（孩子端/家长端共用）
```js
colors: {
  cream:      '#FFF8E7',  // 页面主背景
  sand:       '#F5E6D3',  // 浅沙（底部导航/页脚底）
  wood:       '#E8D5B7',  // 浅木（输入框/分隔线/次要边框）
  leaf:       '#8BC34A',  // 草绿（成功/进度/次要按钮渐变起点）
  leafDark:   '#689F38',  // 深草绿（渐变终点/选中背景）
  leafLight:  '#DCEDC8',  // 浅草绿（完成状态/高亮底）
  sun:        '#FFC107',  // 暖黄（渐变起点）
  orange:     '#FF9800',  // 亮橙（主按钮/星星/强调渐变终点）
  coral:      '#FF7043',  // 珊瑚橙（次要强调）
  sky:        '#4FC3F7',  // 天蓝（奖励主题渐变起点）
  blue:       '#2196F3',  // 蓝色（链接）
  pink:       '#F48FB1',  // 粉色（连续打卡主题）
  pinkDark:   '#EC407A',  // 深粉（渐变终点）
  red:        '#E53935',  // 危险红
  brown:      '#5D4037',  // 深棕（主文字）
  brownLight: '#8D6E63',  // 浅棕（次要文字）
}
```

### 3.2 圆角与阴影
```js
borderRadius: { 'card': '16px', 'card-lg': '20px', 'pill': '20px', 'btn': '16px', 'btn-lg': '18px' }
// 大圆角20px用于孩子端主卡片/大按钮；16px用于标准卡片和按钮
boxShadow: {
  'warm':    '0 4px 15px rgba(93,64,55,0.08)',      // 标准卡片
  'warm-lg': '0 8px 25px rgba(93,64,55,0.12)',      // 悬浮/重卡
  'orange':  '0 4px 12px rgba(255,152,0,0.3)',      // 主按钮
  'btn-press': '0 2px 8px rgba(93,64,55,0.1)',      // 按下态
}
```

### 3.3 字号阶梯
12(辅助/标签) → 13(说明文字) → 14(正文/按钮) → 15(卡片标题) → 16(列表主标题) → 18(区块小标) → 20(卡片大标题) → 24(页面大标题) → 28(关键数字)

### 3.4 动效
```css
@keyframes bounceIn  { 0%{transform:scale(0.3);opacity:0} 50%{scale:1.05} 70%{scale:0.95} 100%{scale:1;opacity:1} }
@keyframes slideUp   { from{transform:translateY(30px);opacity:0} to{transform:none;opacity:1} }
@keyframes float     { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-5px)} }
@keyframes starPulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.1)} }
@keyframes confettiFall { to { transform:translateY(100vh) rotate(360deg); } }  /* 3s 彩色纸屑 */
@keyframes ripple    { to { transform:scale(4); opacity:0; } }                  /* 0.6s 水波纹 */
/* 缓动：cubic-bezier(0.4, 0, 0.2, 1)；入场0.4~0.5s；页头卡片依次延迟0.05~0.15s */
```

### 3.5 两端风格差异
| | 孩子端 | 家长端 |
|---|---|---|
| 导航 | 底部 5 Tab（emoji+文字，active 放大；桌面端 Tab 居中聚拢 gap:48px） | 顶栏（品牌+通知+头像）+ 底部固定模块导航（9 Tab，宽屏均分/窄屏横滑，active 绿胶囊+图标放大） |
| 容器 | 响应式：桌面 max-width:1200px/内容区 1160px，移动(≤768px) max-width:760px/padding 16px | 响应式：max-width:1200px（与 dashboard 基准一致） |
| 卡片 | 20px 大圆角、彩色渐变头卡 | 16px 圆角、白卡+统计卡组 |
| 控件 | 大按钮、大星星 | radio-pill 单选组、stepper 步进器、switch 开关、chip 筛选 |

**孩子端桌面端网格增强**（@media min-width:769px）：首页/打卡页任务卡 2 列；徽章墙 5 列；奖励商店 4 列；我的数据卡 3 列；记录照片墙 4 列。移动端保持原列数不变。
**统一断点**：768px。两端均以 dashboard.html 的 1200px 为桌面基准。

---

## 4. 页面 ↔ PRD 对应关系

### 孩子端
| 页面 | PRD 章节 | 已覆盖的关键逻辑 |
|---|---|---|
| 首页 | 4.1.1 / 4.3.4 / 4.4.2 | 今日任务列表、等级进度条(当前/下一级/进度%)、星星余额、连续打卡、快捷入口 |
| 打卡任务 | 4.1.2~4.1.4 | 任务卡片(积分/连续/状态)、打卡弹窗(文字/照片/视频/语音)、协作任务、等级积分加成提示 |
| 成就 | 4.3.1 / 4.3.4 / 4.8 | 当前等级卡、20级阶梯(启程→传说)、等级奖励预览、徽章墙(五类) |
| 奖励 | 4.4.2~4.4.4 | 星星余额、特权/实物/体验三分类、兑换弹窗(确认+成功动画)、心愿单进度、兑换记录 |
| 我的 | 4.5 / 4.7 | 资料卡、本周统计、编辑资料(头像/昵称/生日/爱好)、主题切换(预留)、设置入口 |
| 记录 | 4.6.1 | 日历视图(图例)、打卡记录列表、照片缩略图、周/月统计 |

### 家长端
| 页面 | PRD 章节 | 已覆盖的关键逻辑 |
|---|---|---|
| dashboard 总览 | 3.1 总览 | 三孩子状态卡、今日待办(待审核/待兑现)、全家统计、7天趋势、动态时间线 |
| 任务管理 | 4.1.1~4.1.3 | 三维筛选(孩子/类型/模式)、批量操作、任务类型管理(5预设+自定义)、创建任务弹窗(全字段：频率/积分/验收/分配/协作)、停用任务置灰 |
| 打卡审核 | 4.1.5 / 4.1.6 | 待审核卡(照片/视频凭证)、通过/打回+评语、48h自动通过警告、历史记录(含打回/自动通过/协作)、免审批额度提示 |
| 奖励管理 | 4.4.2~4.4.4 / 4.4.6 | 兑换审批(余额不足置灰)、已批准待兑现→确认兑现、免审批自动兑换记录、奖励池(CRUD/库存/下架)、许愿墙(采纳为奖励) |
| 等级与成就 | 4.3.1~4.3.4 / 4.8 | 20级阶梯配置(四段位)、三维度加成表(兑换折扣/加成积分/心愿槽位)、等级奖励设置、发放设置、徽章墙配置 |
| 数据面板 | 3.1 数据面板 | 孩子维度(打卡率/积分趋势/类型分布)、任务维度(完成率排行/积分产出/洞察)、时间维度(对比/月度趋势)、本周/本月/全年切换 |
| 成长记录 | 4.6.1 / 4.6.2 | 相册时间线(打卡自动+手动)、多图网格、习惯追踪对比、学习笔记 |
| 家庭成员 | 4.7 / 2.2 | 孩子档案卡(年龄模式)、添加孩子、双家长管理(创建者/共同管理者)、邀请码机制、家庭设置 |
| 设置 | 4.9 / 3.1 设置 | 打卡规则(截止/补打卡/审核超时/免审批额度)、Streak倍率、三层通知偏好、免打扰、数据导出、危险区 |

---

## 5. 交互规格（JS → React 状态）

### 打卡流程（打卡页）
`openCheckin(id)` → 弹窗选类型 → `submitCheckin()` → 任务卡置灰+状态变"审核中" → 余额+等级条不变（审核通过才加分）。
⚠️ PRD 4.1.6：30⭐ 以下免审核自动通过；连续天数决定倍率（7天×1.2/30天×1.5/100天×2.0）。

### 兑换流程（奖励页）
`openExchange(id)` → 确认弹窗 → `confirmExchange()` → 余额扣减 → 成功动画(五彩纸屑+星星雨) → 记录入列表。余额不足按钮置灰。

### 家长端审核（打卡审核页）
`passCard(id)` → 卡片变绿淡出 → 待办数-1；`toggleComment(id)` 展开评语输入；打回需填原因（PRD 4.1.5）。

### 动画映射
全端所有页面的主内容区块均采用 `.animate-in` + `.delay-1~5` 阶梯淡入（fadeInUp，fill-mode: both，家长端 0.5s / 孩子端 0.45s）；SPA 演示版切换 Tab 时会重播该淡入（page-view 由 display:none 切回 block 触发）。实现时保持「进入页面/视图 → 内容块依次上浮淡入」的节奏即可。

| CSS | Framer Motion |
|---|---|
| .animate-in (fadeInUp) | initial={{y:16,opacity:0}} animate={{y:0,opacity:1}}（按 delay-1~5 依次 +0.1s） |
| 按钮 :active scale | whileTap={{scale:0.97}} |
| 水波纹 .ripple | AnimatePresence + motion.span scale 4 fade |
| 纸屑 confettiFall |  react-confetti 或自绘 particle |
| .float / .starPulse | animate={{y:[0,-5,0]}} transition={{repeat:Infinity}} |

### Emoji → Lucide 建议
⭐→Star 🔥→Flame ✅→CheckCircle 📸→Camera 🎬→Video 🎤→Mic 🎁→Gift 🏆→Trophy ⚙️→Settings 📚→BookOpen 🔢→Calculator 🏃→Activity 🧹→Sparkles 🎨→Palette 🔔→Bell 👍→ThumbsUp ✏️→Pencil 👨‍👩‍👧‍👦→Users（组合类保留 emoji 亦可）

---

## 6. Mock 数据口径（接口字段参考）

三孩子：**潼潼**(12岁/👧/余额280⭐/累计620/连续12天/Lv.6🔥黑铁)、**昊昊**(9岁/👦/165⭐/累计480/连续7天/Lv.5🌟闪耀)、**妞妞**(6岁/🧒/90⭐/累计260/连续3天/Lv.4🍀进阶)。
等级口径统一按 PRD 阶梯（累计积分定级）。今日任务：潼潼2/4、昊昊3/5(晨读15⭐/数学20⭐/跳绳10⭐/收拾房间10⭐/英语单词15⭐)、妞妞1/3。
心愿：昊昊乐高千年隼120/300、潼潼素描本100/150、妞妞草莓蛋糕70/80。
家庭加入45天；免审批额度30⭐；审核超时48h；邀请码 STAR-8294。

---

## 7. 已知偏差与说明

- 孩子端 6 页仍沿用旧 mock 等级命名（昊昊 Lv.3⭐进阶 165/250），dashboard 与家长端 8 页已按 PRD 口径（累计积分定级）修正；实现时统一以 PRD 为准。
- 家长端为多页面架构（MPA）：`dashboard.html` 是开发基准首页，9 个独立页面通过底部固定导航栏互相跳转（宽屏 9 Tab 均分，窄屏横向滑动）；`parent-app.html` 仅作单文件演示，开发以独立页为准。
- 家长端登录/注册/表单校验/空状态等标准组件未画，按常规管理后台模式处理即可，风格沿用 Tokens。
- 孩子端"编辑资料"为页内切换视图演示（PRD 未指定弹窗还是跳页），实现时可改为路由。
- 主题切换、语音/视频上传预览是 UI 占位，等后端能力。
- 徽章数据为方便展示有精简，全集以 PRD 4.8 为准。
- 家长端各页 JS 均为演示用本地状态（筛选/开关/弹窗），接 API 时替换为服务端状态。

## 8. 建议落地步骤

0. **搭建插件化骨架**：实现 EventBus（发布/订阅 + 命名空间隔离）+ PluginRegistry（manifest 声明元信息/依赖/权限）+ 模块生命周期管理（init/start/stop/destroy）→ 各功能模块（打卡/积分/等级/奖励/成长记录）作为独立插件目录开发 → 家长后台模块开关控制（禁用模块不加载代码）。PRD §6.3 有完整架构图与通信示例代码。
1. tailwind.config 写入 §3 tokens → 全局引 Fredoka One + Nunito。
2. 先搭公共组件：按钮(橙渐变/绿渐变/白)、卡片、标签、进度条、底部导航(孩子端)/顶栏+模块导航(家长端)、弹窗、chip/radio-pill/stepper/switch。
3. 按 §4 映射逐页迁移，结构基本是一对一 HTML→JSX，CSS 类名→Tailwind。
4. 交互函数改名 hook/状态机，Mock 数据抽成 mock/ 目录等接口替换。
5. 动画最后加，先保证流程通（动效层增强方案见 §9）。

有问题找布布（设计 Agent）或斌哥。🌿

---

## 9. 动效层增强指引（React Bits）

> 定位：**纯增强、零侵入**。React Bits 是 copy-paste 模式的 React 动效组件库（⭐44k+，文档 reactbits.dev，MIT + Commons Clause 可商用）。组件源码直接拷入仓库，不引入 npm 包依赖，可随意改内部实现。页面骨架仍按 §4~§8 开发，动效是最后一步的"皮肤层"，契合本项目「骨架与皮肤解耦」策略。

### 9.1 安装方式（猴子在开发环境执行）

```bash
# 命令模板：npx shadcn@latest add @react-bits/<组件名>-TS-TW
npx shadcn@latest add @react-bits/Particles-TS-TW
```

- **必须选 `-TS-TW` 变体**（TypeScript + Tailwind，与项目栈一致）；装错变体（JS-CSS 等）会引入独立 CSS 文件，破坏 Tailwind tokens 体系
- 组件源码落在 `components/` 目录，随仓库 push，服务器 `docker compose build` 时一并打包，服务器端零额外操作
- 部分组件内部依赖 `motion` 动画库，CLI 会自动写进 package.json，属正常现象
- 组件自带 `'use client'`，Next.js App Router 下直接用即可
- 按需安装，用到哪个装哪个，不要全量装

### 9.2 推荐组件 ↔ 页面映射

效果参照包内 `child-home-reactbits-demo.html`（孩子端首页动效版，浏览器直接打开可交互）。

| React Bits 组件 | 用于 | 效果 |
|---|---|---|
| Particles | 孩子端首页/打卡成功页背景 | 柔光粒子缓慢上浮闪烁 |
| CountUp | 星星余额、等级经验数字 | 数字滚动计数 |
| ShinyText | 星星余额数字 | 呼吸式金光脉冲 |
| ShineBorder | 经验条/心愿进度条 | 高光周期性扫过 |
| FadeContent | 连续打卡标识等内容块 | 弹簧入场 |
| TiltedCard | 任务卡/徽章卡 | 悬停 3D 倾斜 |
| ClickSpark | 打卡/兑换按钮 | 点击粒子爆发庆祝 |

### 9.3 使用原则

1. **先通后美**：业务流程跑通前不装任何动效组件（§8 第 5 步）
2. **孩子端重、家长端轻**：粒子背景、ClickSpark 这类"爽感"动效只上孩子端；家长端最多用 FadeContent / 卡片悬停级别的克制动效
3. **性能兜底**：Particles 在低端安卓机减半粒子数；所有动画只用 transform + opacity（GPU 合成层），不触发布局重排
4. **改色自由**：组件拷贝进仓库后，先把默认配色改成 §3 tokens 的奶油色系再上线

---

> 本内容由 Coze AI 生成，请遵循相关法律法规及《人工智能生成合成内容标识办法》使用与传播。
